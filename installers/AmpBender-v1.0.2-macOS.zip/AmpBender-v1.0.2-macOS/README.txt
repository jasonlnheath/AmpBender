AmpBender v1.0.2 for macOS
==========================

Installation Instructions:

1. AU Plugin (for Logic Pro, GarageBand, Studio One):
   Copy AmpBender.component to:
   ~/Library/Audio/Plug-Ins/Components/

2. VST3 Plugin (for most DAWs):
   Copy AmpBender.vst3 to:
   ~/Library/Audio/Plug-Ins/VST3/

3. Restart your DAW to scan for new plugins.

Quick Install (Terminal):
   cp -R AmpBender.component ~/Library/Audio/Plug-Ins/Components/
   cp -R AmpBender.vst3 ~/Library/Audio/Plug-Ins/VST3/

What's New in v1.0.2:
- Instant switch response using pointerdown events
- All toggles and rotary switches now respond immediately on press
- Improved perceived latency on macOS

Requirements:
- macOS 10.13 or later
- 64-bit DAW with AU or VST3 support

Support: https://github.com/jasonlnheath/plugin-freedom-system
