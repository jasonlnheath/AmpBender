AmpBender v1.0.2 Beta - Installation Instructions
=================================================

INSTALLATION:

1. AU Plugin (for Logic Pro, GarageBand, Studio One):
   Copy AmpBender.component to:
   ~/Library/Audio/Plug-Ins/Components/

2. VST3 Plugin (for Ableton Live, Cubase, Reaper, etc.):
   Copy AmpBender.vst3 to:
   ~/Library/Audio/Plug-Ins/VST3/

AFTER INSTALLATION:

- Restart your DAW
- The plugin should appear in your plugin list as "AmpBender"

WHAT'S NEW IN v1.0.2:

- Instant switch response using pointerdown events
- Reduced UI latency on all toggles and rotary switches
- VST3 resizable window support

SUPPORT:

For issues or feedback: jasonlnheath@gmail.com

Heath Audio 2025
